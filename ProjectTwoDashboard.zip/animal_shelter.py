from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD class for Animal Shelter database operations """

    def __init__(self, username, password):
        # Initializing the MongoClient with authentication for local MongoDB
        self.client = MongoClient('mongodb://%s:%s@localhost:27017' % (username, password))
        self.database = self.client['aac']
        self.collection = self.database['animals']

    # CREATE method
    def create(self, data):
        if data is not None:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"An exception occurred: {e}")
                return False
        else:
            raise ValueError("Nothing to save, data parameter is empty")

    # READ method
    def read(self, query):
        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except Exception as e:
            print(f"An error occurred during read: {e}")
            return []

    # UPDATE method
    def update(self, query, update_data):
        try:
            result = self.collection.update_many(query, {'$set': update_data})
            return result.modified_count
        except Exception as e:
            print(f"An error occurred during update: {e}")
            return 0

    # DELETE method
    def delete(self, query):
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"An error occurred during delete: {e}")
            return 0